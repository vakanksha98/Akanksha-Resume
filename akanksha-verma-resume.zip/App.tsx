import React from 'react';
import Resume from './components/Resume';

const App: React.FC = () => {
  return (
    <div className="w-full">
      <Resume />
    </div>
  );
};

export default App;