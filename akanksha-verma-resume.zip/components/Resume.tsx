import React, { useState, useEffect } from 'react';
import { resumeData } from '../data';
import { 
  Mail, Linkedin, Github, MapPin, Download, 
  ExternalLink, ArrowRight, Code, Terminal, 
  Sparkles, GraduationCap, Cpu, Database, Sun, Moon
} from 'lucide-react';

const Resume: React.FC = () => {
  const { name, title, contact, education, skills, projects, experience, achievements } = resumeData;
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full min-h-screen bg-white dark:bg-slate-950 text-zinc-900 dark:text-slate-200 selection:bg-accentCyan selection:text-black dark:selection:bg-neonBlue overflow-x-hidden relative transition-colors duration-300">
      
      {/* ======================= BACKGROUND DECORATION ======================= */}
      <div className="fixed inset-0 z-0 opacity-[0.03] dark:opacity-[0.05] pointer-events-none transition-colors duration-300" 
           style={{ backgroundImage: isDark ? 'radial-gradient(#22d3ee 1px, transparent 1px)' : 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '24px 24px' }}>
      </div>

      {/* Top Gradient Line */}
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-accentCyan via-black to-accentLime dark:via-neonBlue dark:to-neonPurple z-50"></div>

      {/* ======================= NAVBAR ======================= */}
      <nav className="relative z-40 max-w-5xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="text-xl font-bold tracking-tighter flex items-center gap-1 dark:text-white">
          <div className="w-3 h-3 bg-black dark:bg-neonBlue rounded-full shadow-[0_0_10px_rgba(34,211,238,0.8)] transition-colors"></div>
          AV.
        </div>
        <div className="flex items-center gap-4">
          <a href={`mailto:${contact.email}`} className="hidden md:flex items-center gap-2 text-sm font-medium hover:text-accentCyan dark:hover:text-neonBlue transition-colors">
            Contact Me
          </a>
          
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-slate-800 transition-colors text-zinc-600 dark:text-slate-300"
            aria-label="Toggle Theme"
          >
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
          </button>

          <button 
            onClick={handlePrint}
            className="px-5 py-2 bg-black text-white rounded-full text-sm font-bold hover:bg-zinc-800 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5
            dark:bg-neonBlue dark:text-black dark:hover:bg-cyan-300 dark:shadow-[0_0_15px_rgba(34,211,238,0.4)]"
          >
            Download CV
          </button>
        </div>
      </nav>

      <main className="relative z-10 max-w-5xl mx-auto px-6 pb-24">
        
        {/* ======================= HERO SECTION ======================= */}
        <header className="py-20 md:py-32 text-center relative">
          
          {/* Abstract SVG Background Blob */}
          <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] -z-10 opacity-40 blur-3xl bg-gradient-to-tr rounded-full animate-pulse-slow transition-colors duration-500
            ${isDark ? 'from-neonBlue/20 to-neonPurple/20' : 'from-accentCyan/30 to-accentLime/30'}`}></div>

          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-zinc-200 shadow-sm text-xs font-bold uppercase tracking-wider text-zinc-600 mb-8 animate-fade-in-up
            dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 transition-colors">
             <span className="relative flex h-2 w-2">
               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75 dark:bg-neonBlue"></span>
               <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500 dark:bg-cyan-400"></span>
             </span>
             Available for ML & SDE Roles
          </div>
          
          <h1 className="text-6xl md:text-8xl font-bold tracking-tighter mb-6 leading-[0.9] text-zinc-900 dark:text-white transition-colors">
            Bridging Math & <br className="hidden md:block" />
            <span className="relative inline-block">
              <span className="relative z-10 text-transparent bg-clip-text bg-gradient-to-r from-black via-zinc-700 to-black dark:from-white dark:via-slate-300 dark:to-white">Machine Intel.</span>
              <svg className="absolute -bottom-2 left-0 w-full h-3 text-accentCyan dark:text-neonPurple opacity-50 -z-0" viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="3" fill="none" />
              </svg>
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-zinc-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed mb-10 font-light transition-colors">
            I'm <span className="font-semibold text-black dark:text-neonBlue">{name}</span>. A Master's Candidate at IIT Kharagpur building scalable AI pipelines and robust software.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <a href={`https://${contact.github}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-6 py-3 bg-zinc-100 hover:bg-zinc-200 rounded-xl font-bold text-black transition-all
             dark:bg-slate-900 dark:text-white dark:hover:bg-slate-800 dark:border dark:border-slate-800">
              <Github size={20} /> GitHub
            </a>
            <a href={`https://${contact.linkedin}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-6 py-3 bg-black hover:bg-zinc-800 rounded-xl font-bold text-white transition-all shadow-xl hover:shadow-2xl
             dark:bg-neonBlue dark:text-black dark:hover:bg-cyan-300 dark:shadow-[0_0_20px_rgba(34,211,238,0.3)]">
              <Linkedin size={20} /> LinkedIn
            </a>
          </div>
        </header>

        {/* ======================= MARQUEE ======================= */}
        <div className="relative w-screen left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] bg-zinc-900 dark:bg-black text-white py-4 overflow-hidden mb-24 rotate-1 shadow-2xl dark:shadow-[0_0_30px_rgba(0,0,0,0.5)] dark:border-y dark:border-slate-800 transition-all">
           <div className="flex whitespace-nowrap animate-marquee">
              {[...Array(10)].map((_, i) => (
                 <span key={i} className="mx-8 text-lg font-bold uppercase tracking-widest flex items-center gap-4 opacity-90">
                   Machine Learning <Sparkles size={14} className="text-accentCyan dark:text-neonBlue" /> 
                   Data Science <Sparkles size={14} className="text-accentLime dark:text-neonPurple" /> 
                   Software Engineering <Sparkles size={14} className="text-purple-400 dark:text-cyan-400" />
                 </span>
              ))}
           </div>
        </div>

        {/* ======================= EDUCATION (Central Highlight) ======================= */}
        <section className="mb-32">
           <div className="flex items-center gap-4 mb-12 justify-center">
              <div className="h-px bg-zinc-200 dark:bg-slate-800 w-16 md:w-32 transition-colors"></div>
              <h2 className="text-3xl font-bold text-center flex items-center gap-3 dark:text-white">
                <GraduationCap className="text-accentCyan dark:text-neonBlue" /> Academic Foundation
              </h2>
              <div className="h-px bg-zinc-200 dark:bg-slate-800 w-16 md:w-32 transition-colors"></div>
           </div>

           <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {education.map((edu, idx) => (
                <div key={idx} className="group relative bg-white dark:bg-slate-900/50 border border-zinc-200 dark:border-slate-800 p-8 rounded-2xl shadow-sm hover:shadow-xl hover:border-black dark:hover:border-neonBlue transition-all duration-300 backdrop-blur-sm">
                   <div className="absolute top-0 right-0 bg-zinc-100 dark:bg-slate-800 text-zinc-600 dark:text-slate-300 px-4 py-1 rounded-bl-xl rounded-tr-xl text-xs font-bold uppercase tracking-wider group-hover:bg-black group-hover:text-white dark:group-hover:bg-neonBlue dark:group-hover:text-black transition-colors">
                     {edu.year}
                   </div>
                   <h3 className="text-xl font-bold mb-1 group-hover:text-accentCyan dark:group-hover:text-neonBlue transition-colors dark:text-slate-100">{edu.institution}</h3>
                   <p className="text-zinc-600 dark:text-slate-400 font-medium mb-4">{edu.degree}</p>
                   <div className="flex items-center gap-2 text-sm font-mono bg-zinc-50 dark:bg-slate-950 inline-block px-3 py-1 rounded border border-zinc-100 dark:border-slate-800 dark:text-cyan-300">
                     <span className="w-2 h-2 rounded-full bg-accentLime dark:bg-neonPurple"></span>
                     {edu.score}
                   </div>
                </div>
              ))}
           </div>
        </section>

        {/* ======================= PROJECTS GRID ======================= */}
        <section className="mb-32">
           <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4 border-b border-zinc-100 dark:border-slate-800 pb-4 transition-colors">
              <div>
                <h3 className="text-sm font-bold text-accentCyan dark:text-neonBlue uppercase tracking-widest mb-1">Portfolio</h3>
                <h2 className="text-4xl font-bold dark:text-white">Selected Works</h2>
              </div>
              <div className="hidden md:block text-zinc-400 dark:text-slate-500 text-sm font-mono">
                // SHOWCASING SKILLS
              </div>
           </div>

           <div className="grid md:grid-cols-2 gap-8">
              {projects.map((project, idx) => (
                <div key={idx} className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-zinc-100 dark:border-slate-800 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)] dark:shadow-none dark:hover:shadow-[0_0_20px_rgba(0,243,255,0.1)] transition-all flex flex-col group dark:hover:border-slate-700">
                   <div className="flex justify-between items-start mb-6">
                      <div className="flex gap-2 flex-wrap">
                        {project.tech.split(',').slice(0, 2).map((t, i) => (
                           <span key={i} className="px-2 py-1 bg-zinc-100 dark:bg-slate-800 rounded text-[10px] font-bold uppercase tracking-wide text-zinc-600 dark:text-slate-300 border border-zinc-200 dark:border-slate-700">
                             {t.trim()}
                           </span>
                        ))}
                      </div>
                      <div className="p-2 bg-zinc-50 dark:bg-slate-800 rounded-full border border-zinc-100 dark:border-slate-700 group-hover:bg-accentLime group-hover:border-accentLime dark:group-hover:bg-neonPurple dark:group-hover:border-neonPurple transition-colors">
                         <Code size={18} className="text-zinc-400 dark:text-slate-400 group-hover:text-black dark:group-hover:text-white" />
                      </div>
                   </div>

                   <h3 className="text-2xl font-bold mb-3 group-hover:underline decoration-2 decoration-accentCyan dark:decoration-neonBlue underline-offset-4 dark:text-slate-100">{project.title}</h3>
                   
                   <ul className="space-y-3 mb-8 flex-grow">
                     {project.points.map((point, i) => (
                       <li key={i} className="text-zinc-600 dark:text-slate-400 text-sm leading-relaxed flex items-start gap-3">
                         <span className="mt-1.5 w-1 h-1 rounded-full bg-black dark:bg-neonBlue shrink-0"></span>
                         {point}
                       </li>
                     ))}
                   </ul>

                   {project.githubUrl && (
                     <a href={project.githubUrl} target="_blank" rel="noreferrer" className="mt-auto w-full py-3 rounded-lg border border-zinc-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-bold text-sm text-center hover:bg-black dark:hover:bg-neonBlue dark:hover:text-black hover:text-white hover:border-black dark:hover:border-neonBlue transition-all flex items-center justify-center gap-2 dark:text-slate-300">
                       View Source <ExternalLink size={14} />
                     </a>
                   )}
                </div>
              ))}
           </div>
        </section>

        {/* ======================= SKILLS & EXPERIENCE SPLIT ======================= */}
        <section className="grid lg:grid-cols-12 gap-12">
           
           {/* Left: Skills (4 cols) */}
           <div className="lg:col-span-4 space-y-8">
              <h3 className="text-2xl font-bold flex items-center gap-2 dark:text-white">
                <Terminal size={24} /> Technical Arsenal
              </h3>
              
              <div className="bg-zinc-50 dark:bg-slate-900 rounded-2xl p-6 border border-zinc-100 dark:border-slate-800 transition-colors">
                {skills.map((cat, idx) => (
                  <div key={idx} className="mb-6 last:mb-0">
                    <h4 className="text-xs font-bold text-zinc-400 dark:text-slate-500 uppercase tracking-widest mb-3">{cat.category}</h4>
                    <div className="flex flex-wrap gap-2">
                      {cat.items.map((skill, i) => (
                        <span key={i} className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-zinc-200 dark:border-slate-700 rounded-md text-sm font-medium text-zinc-700 dark:text-slate-300 shadow-sm">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Achievements Mini-Card */}
              <div className="bg-black dark:bg-slate-900 text-white rounded-2xl p-6 relative overflow-hidden dark:border dark:border-slate-800">
                <div className="absolute top-0 right-0 w-24 h-24 bg-accentCyan dark:bg-neonBlue blur-[50px] opacity-30"></div>
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Sparkles size={16} className="text-accentLime dark:text-neonBlue" /> Key Achievements
                </h3>
                <div className="space-y-4">
                  {achievements.map((ach, idx) => (
                    <div key={idx}>
                       <div className="font-bold text-accentCyan dark:text-neonPurple text-sm">{ach.title}</div>
                       <div className="text-xs text-zinc-400 dark:text-slate-400">{ach.description}</div>
                    </div>
                  ))}
                </div>
              </div>
           </div>

           {/* Right: Experience (8 cols) */}
           <div className="lg:col-span-8">
              <h3 className="text-2xl font-bold mb-8 flex items-center gap-2 dark:text-white">
                 <Cpu size={24} /> Professional Experience
              </h3>
              
              <div className="space-y-6">
                 {experience.map((exp, idx) => (
                   <div key={idx} className="flex gap-6 group">
                      <div className="flex flex-col items-center">
                         <div className="w-4 h-4 rounded-full bg-zinc-200 dark:bg-slate-700 border-2 border-white dark:border-slate-900 shadow-sm group-hover:bg-accentCyan dark:group-hover:bg-neonBlue transition-colors"></div>
                         <div className="w-0.5 flex-1 bg-zinc-100 dark:bg-slate-800 my-2 transition-colors"></div>
                      </div>
                      <div className="pb-8">
                         <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-2">
                            <h4 className="text-xl font-bold dark:text-slate-200">{exp.role}</h4>
                            <span className="text-xs font-bold px-2 py-1 bg-zinc-100 dark:bg-slate-800 rounded text-zinc-500 dark:text-slate-400">{exp.date}</span>
                         </div>
                         <div className="text-sm font-semibold text-zinc-500 dark:text-slate-500 mb-3 uppercase tracking-wide">{exp.company}</div>
                         <p className="text-zinc-600 dark:text-slate-400 leading-relaxed">
                            {exp.points[0]}
                         </p>
                      </div>
                   </div>
                 ))}
              </div>
           </div>

        </section>

        {/* ======================= FOOTER CTA ======================= */}
        <footer className="mt-32 text-center border-t border-zinc-100 dark:border-slate-800 pt-16 transition-colors">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 dark:text-white">Ready to make an impact.</h2>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
               <a href={`mailto:${contact.email}`} className="px-8 py-4 bg-black text-white rounded-full font-bold hover:scale-105 transition-transform shadow-xl
               dark:bg-neonBlue dark:text-black dark:hover:bg-cyan-300 dark:shadow-[0_0_20px_rgba(34,211,238,0.5)]">
                 Let's Talk
               </a>
               <a href={`https://${contact.linkedin}`} target="_blank" rel="noreferrer" className="px-8 py-4 bg-white border border-zinc-200 text-black rounded-full font-bold hover:bg-zinc-50 transition-colors
               dark:bg-transparent dark:border-slate-700 dark:text-white dark:hover:bg-slate-900">
                 Connect on LinkedIn
               </a>
            </div>
            <p className="mt-12 text-zinc-400 dark:text-slate-600 text-sm">© {new Date().getFullYear()} Akanksha Verma. Crafted with precision.</p>
        </footer>

      </main>
    </div>
  );
};

export default Resume;